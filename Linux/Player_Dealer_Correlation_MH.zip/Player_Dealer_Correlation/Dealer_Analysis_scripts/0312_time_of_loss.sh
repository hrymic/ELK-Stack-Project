#!/bin/bash
grep "$1 $2" 0312_Roulette_Dealers
