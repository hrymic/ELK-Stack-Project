#!/bin/bash
grep "$1 $2" 0315_Roulette_Dealers
