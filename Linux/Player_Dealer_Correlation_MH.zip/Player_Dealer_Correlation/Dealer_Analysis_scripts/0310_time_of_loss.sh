#!/bin/bash
grep "$1 $2" 0310_Roulette_Dealers
