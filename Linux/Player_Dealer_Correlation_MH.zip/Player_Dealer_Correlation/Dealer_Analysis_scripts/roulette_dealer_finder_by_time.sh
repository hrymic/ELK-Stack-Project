#!/bin/bash
grep "$1 $2" $3_Dealer_schedule
